import 'package:flutter/material.dart';
import 'fragments.dart';
import 'teste.dart';

void main() {runApp(MaterialApp(
  home: Teste(), //Home(),
));}


