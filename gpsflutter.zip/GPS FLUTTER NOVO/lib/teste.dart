import 'package:flutter/material.dart';

class Teste extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(150, 132, 64, 166),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(150, 132, 64, 120),
        leading: const Icon(
          Icons.arrow_back,
          size: 40,
          color: Color.fromARGB(255, 254, 169, 1),
        ),
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(30, 20, 30, 0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                backgroundColor: Color.fromARGB(150, 132, 64, 120),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                )
              ),
              onPressed: (){},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(
                    Icons.app_registration,
                    size: 30,
                    color: Color.fromARGB(255, 254, 169, 1),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                    child: const Text(
                      'Registrar Culto',
                      style: TextStyle(
                        color: Color.fromARGB(255, 254, 169, 1),
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(30, 20, 30, 0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                backgroundColor: Color.fromARGB(150, 132, 64, 120),
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                )
              ),
              onPressed: (){},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(
                    Icons.person_add,
                    size: 30,
                    color: Color.fromARGB(255, 254, 169, 1),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                    child: const Text(
                      'Cadastrar Criança',
                      style: TextStyle(
                        color: Color.fromARGB(255, 254, 169, 1),
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(30, 20, 30, 0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                backgroundColor: Color.fromARGB(150, 132, 64, 120),
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                )
              ),
              onPressed: (){},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(
                    Icons.calendar_month,
                    size: 30,
                    color: Color.fromARGB(255, 254, 169, 1),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                    child: const Text(
                      'Escala de Voluntários',
                      style: TextStyle(
                        color: Color.fromARGB(255, 254, 169, 1),
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  /*Opacity(
                    opacity: 0,
                    child: Icon(Icons.calendar_month),
                  ),*/
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}