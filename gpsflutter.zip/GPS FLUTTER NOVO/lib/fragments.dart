import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /*appBar: AppBar(
        title: Text('GPS'),
          backgroundColor: Colors.indigo[300]),*/
      backgroundColor: Color.fromARGB(150, 132, 64, 166),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Spacer(),
          Container(
            margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
            child: Image.asset('imagens/gps_logo_dif_cor.png'),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 30, 0, 10),
            child: ElevatedButton(
              onPressed: (){},
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.fromLTRB(30, 5, 30, 5),
                backgroundColor: Color.fromARGB(255, 254, 169, 1),
              ),
              child: const Text(
                'Sou Voluntário',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
            child: ElevatedButton(
              onPressed: (){},
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.fromLTRB(30, 5, 30, 5),
                backgroundColor: Color.fromARGB(255, 254, 169, 1),
              ),
              child: const Text(
                'Sou Pai/Mãe',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 30, 20, 10),
            child: const Text(
              'Ensina a criança no caminho em que deve andar, e ainda quando for velho,'
                  ' não se desviará dele. Pv. 22:6',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
              ),
            ),
          ),
          Spacer(),
          Container(
            margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(20, 0, 0, 0),
                  child: ElevatedButton(
                    onPressed: (){},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color.fromARGB(255, 254, 169, 1),
                    ),
                    child: const Text(
                      'Cadastre-se',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                  child: IconButton(
                    onPressed: (){},
                    icon: Icon(Icons.logout_outlined),
                    color: Color.fromARGB(255, 254, 169, 1),
                    iconSize: 35,
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}


